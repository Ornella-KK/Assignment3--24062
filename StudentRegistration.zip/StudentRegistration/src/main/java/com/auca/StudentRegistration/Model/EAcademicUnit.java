package com.auca.StudentRegistration.Model;

public enum EAcademicUnit{
        Programme,
        Faculty,
        Department
}
